import React, { useState } from 'react';
import {
  Download,
  Settings,
  Key,
  ShieldCheck,
  Check,
  Menu,
  Share2,
  ExternalLink,
  Search,
  Printer,
  Moon,
  Sun,
  AlertCircle,
  Globe,
  FileText,
  Shield,
  Layers,
} from 'lucide-react';
import { AnalysisResult } from '../types';
import { generateOnboardingMarkdown } from '../lib/exportMarkdown';

interface HeaderProps {
  onOpenUrlSwap: () => void;
  analysisData: AnalysisResult | null;
  githubToken: string;
  onSaveGithubToken: (token: string) => void;
  geminiKey: string;
  onSaveGeminiKey: (key: string) => void;
  onToggleSidebar?: () => void;
  onShare?: () => void;
  onOpenSearch?: () => void;
  isDarkMode?: boolean;
  onToggleDarkMode?: () => void;
  onOpenDomainModal?: () => void;
  onOpenPrivacyModal?: () => void;
  onOpenTermsModal?: () => void;
  activeTitle?: string;
  activeSubtitle?: string;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenUrlSwap,
  analysisData,
  githubToken,
  onSaveGithubToken,
  geminiKey,
  onSaveGeminiKey,
  onToggleSidebar,
  onShare,
  onOpenSearch,
  isDarkMode,
  onToggleDarkMode,
  onOpenDomainModal,
  onOpenPrivacyModal,
  onOpenTermsModal,
  activeTitle = 'RepoAI',
  activeSubtitle = 'Repository Architecture & Setup Inspector',
}) => {
  const [showSettings, setShowSettings] = useState(false);
  const [tempGhToken, setTempGhToken] = useState(githubToken);
  const [tempGeminiKey, setTempGeminiKey] = useState(geminiKey);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    const cleanGh = tempGhToken.trim();
    const cleanGemini = tempGeminiKey.trim();

    // Form validation
    if (cleanGh && cleanGh.length < 15) {
      setFormError('GitHub personal access token should typically be at least 40 characters.');
      return;
    }

    onSaveGithubToken(cleanGh);
    onSaveGeminiKey(cleanGemini);
    setSaveSuccess(true);
    setTimeout(() => {
      setSaveSuccess(false);
      setShowSettings(false);
    }, 1500);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleExportMarkdown = () => {
    if (!analysisData) return;
    const markdown = generateOnboardingMarkdown(analysisData);
    const blob = new Blob([markdown], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `ONBOARDING_${analysisData.metadata.repo.toUpperCase()}.md`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between px-4 sm:px-6 py-3 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0D1117] transition-colors print:hidden">
      {/* Left Title & Subtitle */}
      <div className="flex items-center gap-3">
        {onToggleSidebar && (
          <button
            onClick={onToggleSidebar}
            className="p-1.5 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="Toggle Navigation Menu"
            aria-label="Toggle Navigation Menu"
          >
            <Menu className="w-5 h-5" />
          </button>
        )}

        <div>
          <h1 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <span>{analysisData ? analysisData.metadata.fullName : activeTitle}</span>
            {analysisData && (
              <a
                href={analysisData.metadata.htmlUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-slate-400 hover:text-blue-500 transition-colors"
                title="View on GitHub"
              >
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            )}
          </h1>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">
            {analysisData ? 'Repository Architecture Inspector' : activeSubtitle}
          </p>
        </div>
      </div>

      {/* Action Controls */}
      <div className="flex items-center gap-1.5 sm:gap-2">
        {/* Custom Domain Trigger */}
        {onOpenDomainModal && (
          <button
            onClick={onOpenDomainModal}
            className="px-2.5 py-1.5 text-xs font-mono rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hidden md:flex items-center gap-1.5 transition-colors"
            title="Custom Domain Configuration"
          >
            <Globe className="w-3.5 h-3.5 text-blue-500" />
            <span>repoai.dev</span>
          </button>
        )}

        {/* Global Site Search Trigger */}
        {onOpenSearch && (
          <button
            onClick={onOpenSearch}
            className="px-2.5 py-1.5 text-xs rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 flex items-center gap-2 transition-colors"
            title="Search site & tools (Ctrl+K / Cmd+K)"
          >
            <Search className="w-3.5 h-3.5 text-blue-500" />
            <span className="hidden md:inline text-[11px]">Search</span>
            <kbd className="hidden sm:inline-block px-1.5 py-0.2 text-[10px] font-mono bg-white dark:bg-slate-900 text-slate-500 rounded border border-slate-200 dark:border-slate-800">
              Ctrl+K
            </kbd>
          </button>
        )}

        {/* Dark Mode Toggle */}
        {onToggleDarkMode && (
          <button
            onClick={onToggleDarkMode}
            className="p-2 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title={isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            aria-label="Toggle Dark and Light Mode"
          >
            {isDarkMode ? (
              <Sun className="w-4 h-4 text-amber-400" />
            ) : (
              <Moon className="w-4 h-4 text-slate-600" />
            )}
          </button>
        )}

        {/* Share Button */}
        {onShare && (
          <button
            onClick={onShare}
            className="p-2 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="Share repository link"
          >
            <Share2 className="w-4 h-4" />
          </button>
        )}

        {/* Print Stylesheet Trigger */}
        <button
          onClick={handlePrint}
          className="p-2 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors hidden sm:block"
          title="Print Onboarding Runbook (Ctrl+P)"
        >
          <Printer className="w-4 h-4" />
        </button>

        {/* URL Swap Modal Trigger */}
        <button
          onClick={onOpenUrlSwap}
          className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-blue-50 hover:bg-blue-100 dark:bg-blue-950/40 dark:hover:bg-blue-900/50 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-900/50 flex items-center gap-1.5 transition-colors"
        >
          <Layers className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
          <span className="hidden sm:inline">URL Swap Matrix</span>
        </button>

        {/* Export Onboarding Guide Button */}
        <button
          onClick={handleExportMarkdown}
          disabled={!analysisData}
          className={`px-3 py-1.5 text-xs font-medium rounded-lg flex items-center gap-1.5 transition-colors ${
            analysisData
              ? 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 cursor-pointer'
              : 'bg-slate-50 dark:bg-slate-900 text-slate-400 dark:text-slate-600 border border-slate-200 dark:border-slate-800/60 cursor-not-allowed opacity-60'
          }`}
          title={analysisData ? 'Download ONBOARDING_{REPO}.md' : 'Analyze a repository first to export'}
        >
          <Download className="w-3.5 h-3.5 text-slate-600 dark:text-slate-400" />
          <span className="hidden md:inline">Export Runbook</span>
        </button>

        {/* Settings Popover Button */}
        <div className="relative">
          <button
            onClick={() => setShowSettings(!showSettings)}
            className={`p-2 rounded-lg border transition-colors ${
              githubToken || geminiKey
                ? 'bg-blue-50 dark:bg-blue-950/40 border-blue-200 dark:border-blue-800 text-blue-600 dark:text-blue-400'
                : 'bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
            title="Configure GitHub Token & API Credentials"
          >
            <Settings className="w-4 h-4" />
          </button>

          {/* Settings Dropdown Popover */}
          {showSettings && (
            <div className="absolute right-0 mt-2 w-80 sm:w-96 p-4 rounded-xl bg-white dark:bg-[#161B22] border border-slate-200 dark:border-slate-700 shadow-xl z-50 text-xs">
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-blue-500" />
                  <span className="font-bold text-slate-900 dark:text-white text-sm">Credentials & API Access</span>
                </div>
                <span className="text-[10px] text-slate-400 font-mono">client-side only</span>
              </div>

              {/* Form Success State Banner */}
              {saveSuccess && (
                <div className="mb-3 p-2.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/50 flex items-center gap-2 text-emerald-800 dark:text-emerald-300 text-xs font-semibold">
                  <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                  <span>Credentials stored securely in browser localStorage</span>
                </div>
              )}

              {/* Form Error State Banner */}
              {formError && (
                <div className="mb-3 p-2.5 rounded-lg bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/50 flex items-center gap-2 text-rose-800 dark:text-rose-300 text-xs">
                  <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              <form onSubmit={handleSaveSettings} className="space-y-3.5">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                      <Key className="w-3.5 h-3.5 text-slate-400" />
                      GitHub Personal Access Token (Optional)
                    </label>
                  </div>
                  <input
                    type="password"
                    value={tempGhToken}
                    onChange={(e) => {
                      setTempGhToken(e.target.value);
                      if (formError) setFormError(null);
                    }}
                    placeholder="ghp_... (Unlocks 5,000 req/hr rate limit)"
                    className="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 focus:border-blue-500 focus:outline-none text-slate-800 dark:text-slate-200 font-mono text-xs placeholder:text-slate-400"
                  />
                  <p className="mt-1 text-[11px] text-slate-400">
                    Bypasses the public 60 req/hr unauthenticated limit during analysis.
                  </p>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                      <Key className="w-3.5 h-3.5 text-slate-400" />
                      Gemini API Key (Optional)
                    </label>
                  </div>
                  <input
                    type="password"
                    value={tempGeminiKey}
                    onChange={(e) => {
                      setTempGeminiKey(e.target.value);
                      if (formError) setFormError(null);
                    }}
                    placeholder="AIzaSy... (Gemini API synthesis)"
                    className="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 focus:border-blue-500 focus:outline-none text-slate-800 dark:text-slate-200 font-mono text-xs placeholder:text-slate-400"
                  />
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={() => {
                      setTempGhToken('');
                      setTempGeminiKey('');
                      onSaveGithubToken('');
                      onSaveGeminiKey('');
                      setSaveSuccess(true);
                      setTimeout(() => setSaveSuccess(false), 1200);
                    }}
                    className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 text-xs"
                  >
                    Clear keys
                  </button>

                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-lg font-semibold bg-blue-600 hover:bg-blue-500 text-white flex items-center gap-1.5 transition-colors shadow-sm"
                  >
                    {saveSuccess ? <Check className="w-3.5 h-3.5" /> : null}
                    <span>{saveSuccess ? 'Saved' : 'Save Credentials'}</span>
                  </button>
                </div>
              </form>

              {/* Legal and Domain Quick Links */}
              <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-500">
                {onOpenPrivacyModal && (
                  <button onClick={onOpenPrivacyModal} className="hover:underline hover:text-slate-800 dark:hover:text-slate-200">
                    Privacy Policy
                  </button>
                )}
                {onOpenTermsModal && (
                  <button onClick={onOpenTermsModal} className="hover:underline hover:text-slate-800 dark:hover:text-slate-200">
                    Terms & Conditions
                  </button>
                )}
                {onOpenDomainModal && (
                  <button onClick={onOpenDomainModal} className="hover:underline hover:text-slate-800 dark:hover:text-slate-200">
                    Custom Domain
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
