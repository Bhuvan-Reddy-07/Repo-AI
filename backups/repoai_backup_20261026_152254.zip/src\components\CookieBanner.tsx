import React, { useState, useEffect } from 'react';
import { Cookie, X, ShieldCheck } from 'lucide-react';

export const CookieBanner: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [showPreferences, setShowPreferences] = useState(false);
  const [analyticsEnabled, setAnalyticsEnabled] = useState(true);

  useEffect(() => {
    const consent = localStorage.getItem('repo_ai_cookie_consent');
    if (!consent) {
      // Show banner after brief delay
      const timer = setTimeout(() => setIsOpen(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAcceptAll = () => {
    localStorage.setItem('repo_ai_cookie_consent', JSON.stringify({ essential: true, analytics: true, date: new Date().toISOString() }));
    setIsOpen(false);
  };

  const handleAcceptEssential = () => {
    localStorage.setItem('repo_ai_cookie_consent', JSON.stringify({ essential: true, analytics: false, date: new Date().toISOString() }));
    setIsOpen(false);
  };

  const handleSaveCustom = () => {
    localStorage.setItem('repo_ai_cookie_consent', JSON.stringify({ essential: true, analytics: analyticsEnabled, date: new Date().toISOString() }));
    setIsOpen(false);
  };

  if (!isOpen) return null;

  return (
    <aside
      id="cookie-banner"
      role="region"
      aria-label="Cookie consent banner"
      className="fixed bottom-4 left-4 right-4 sm:left-auto sm:right-6 sm:max-w-md z-50 p-4 sm:p-5 rounded-3xl bg-white/95 dark:bg-[#161B22]/95 backdrop-blur-xl border border-slate-200 dark:border-slate-800 shadow-2xl animate-fadeIn print:hidden"
    >
      <div className="flex items-start gap-3">
        <div className="p-2 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800/40 shrink-0">
          <Cookie className="w-5 h-5" />
        </div>

        <div className="flex-1 space-y-2">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <span>Privacy & Storage Preferences</span>
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
            </h4>
            <button
              onClick={handleAcceptEssential}
              className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
              title="Close and keep essential"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
            RepoAI stores your local theme preference, encrypted session history, and optional API keys entirely in your browser. We never track private code or sell data.
          </p>

          {showPreferences && (
            <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 space-y-2 text-[11px]">
              <div className="flex items-center justify-between">
                <div>
                  <span className="font-semibold text-slate-800 dark:text-slate-200 block">Essential Storage</span>
                  <span className="text-slate-500 text-[10px]">Session state & dark mode preference</span>
                </div>
                <span className="text-[10px] font-mono text-emerald-500 font-bold">Required</span>
              </div>
              <div className="flex items-center justify-between pt-1 border-t border-slate-200 dark:border-slate-800">
                <div>
                  <span className="font-semibold text-slate-800 dark:text-slate-200 block">Performance Telemetry</span>
                  <span className="text-slate-500 text-[10px]">Anonymous latency metrics for API checks</span>
                </div>
                <input
                  type="checkbox"
                  checked={analyticsEnabled}
                  onChange={(e) => setAnalyticsEnabled(e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-indigo-500"
                />
              </div>
            </div>
          )}

          <div className="flex flex-wrap items-center gap-2 pt-1">
            {showPreferences ? (
              <button
                onClick={handleSaveCustom}
                className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white transition-colors shadow-sm"
              >
                Save Preferences
              </button>
            ) : (
              <button
                onClick={handleAcceptAll}
                className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white transition-colors shadow-sm"
              >
                Accept All
              </button>
            )}

            <button
              onClick={handleAcceptEssential}
              className="px-3 py-1.5 rounded-xl text-xs font-medium bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition-colors"
            >
              Essential Only
            </button>

            <button
              onClick={() => setShowPreferences(!showPreferences)}
              className="text-[11px] text-slate-500 hover:text-indigo-600 dark:hover:text-indigo-400 underline ml-auto"
            >
              {showPreferences ? 'Hide options' : 'Customize'}
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
};
