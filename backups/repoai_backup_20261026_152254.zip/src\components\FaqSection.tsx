import React, { useState } from 'react';
import { ChevronDown, HelpCircle, Sparkles } from 'lucide-react';

interface FaqItem {
  question: string;
  answer: string;
  category: string;
}

const FAQ_DATA: FaqItem[] = [
  {
    question: 'What is the 1-Word GitHub URL Swap Magic?',
    answer:
      'Simply replace "github" in any repository URL with one of 7 keywords: gitdiagram (interactive architecture flowcharts), gitingest (single-file LLM prompt digests), gitreverse (reverse-engineered data models), explaingithub (AI codebase walkthroughs), uithub (distraction-free web file browser), github1s (full in-browser VS Code editor in WebAssembly), or deepwiki (executive architecture wiki). Formula: https://[keyword].com/[username]/[repo name].',
    category: 'Ecosystem & Tricks',
  },
  {
    question: 'How are setup and test commands extracted without mock data?',
    answer:
      'RepoAI inspects the ground-truth repository manifests (e.g. package.json, requirements.txt, pyproject.toml, Cargo.toml, Go modules, Makefile) and actual CI pipeline definitions (.github/workflows/*.yml) to harvest exact, verified commands rather than hallucinating generic instructions.',
    category: 'Verification Engine',
  },
  {
    question: 'How does RepoAI link beginner issues to specific files to edit?',
    answer:
      'Our engine fetches active issues tagged with "good first issue" or "help wanted" via the GitHub API, correlates issue descriptions with the project\'s recursive git directory tree, and recommends the precise source files and an actionable 3-step action plan to get started.',
    category: 'Beginner Tasks',
  },
  {
    question: 'Can I export the full onboarding guide to Markdown or Print?',
    answer:
      'Yes! You can click "Export ONBOARDING.md" to download a clean, publication-ready markdown file formatted for adding straight into your repository as ONBOARDING.md, or use your browser\'s Print function (Ctrl+P / Cmd+P) for a print-optimized runbook.',
    category: 'Export & Docs',
  },
  {
    question: 'Is my data secure, and are private repositories supported?',
    answer:
      'RepoAI runs completely client-side in your browser. All analysis, state, and tokens are stored in your browser\'s localStorage. To analyze private repositories or increase your GitHub API rate limit from 60 to 5,000 requests/hr, add your personal GitHub token in Settings.',
    category: 'Security & Privacy',
  },
];

export const FaqSection: React.FC<{ className?: string }> = ({ className = '' }) => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleAccordion = (idx: number) => {
    setOpenIndex((prev) => (prev === idx ? null : idx));
  };

  return (
    <div className={`rounded-3xl bg-white dark:bg-[#161B22] border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-xl space-y-5 ${className}`}>
      <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800/40">
            <HelpCircle className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Frequently Asked Questions
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Everything you need to know about RepoAI and the open-source onboarding engine.
            </p>
          </div>
        </div>
        <span className="hidden sm:inline-flex items-center gap-1 text-[11px] font-mono text-blue-600 dark:text-sky-400 bg-blue-50 dark:bg-blue-950/40 px-2.5 py-1 rounded-md border border-blue-200 dark:border-blue-800/40">
          <HelpCircle className="w-3 h-3" /> 5 Verified FAQs
        </span>
      </div>

      <div className="space-y-2.5">
        {FAQ_DATA.map((item, idx) => {
          const isOpen = openIndex === idx;
          return (
            <div
              key={idx}
              className={`rounded-2xl border transition-all duration-200 overflow-hidden ${
                isOpen
                  ? 'bg-slate-50/80 dark:bg-slate-900/60 border-indigo-300 dark:border-indigo-900/50 shadow-sm'
                  : 'bg-white dark:bg-[#161B22] border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
              }`}
            >
              <button
                onClick={() => toggleAccordion(idx)}
                className="w-full px-4 py-3.5 text-left flex items-center justify-between gap-3 focus:outline-none"
              >
                <div className="flex items-center gap-2.5">
                  <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                    {item.category}
                  </span>
                  <span className="text-xs sm:text-sm font-semibold text-slate-900 dark:text-white">
                    {item.question}
                  </span>
                </div>
                <ChevronDown
                  className={`w-4 h-4 text-slate-400 transition-transform duration-200 shrink-0 ${
                    isOpen ? 'rotate-180 text-indigo-500' : ''
                  }`}
                />
              </button>

              {isOpen && (
                <div className="px-4 pb-4 pt-1 text-xs text-slate-600 dark:text-slate-300 leading-relaxed border-t border-slate-100 dark:border-slate-800/60 animate-fadeIn">
                  {item.answer}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
