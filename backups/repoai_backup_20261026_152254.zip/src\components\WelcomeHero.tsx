import React, { useState } from 'react';
import {
  Terminal,
  Layers,
  Code2,
  FileCode,
  BookOpen,
  ArrowRight,
  Copy,
  Check,
  ExternalLink,
  Shield,
  Search,
} from 'lucide-react';

interface WelcomeHeroProps {
  onQuickAction: (actionType: 'explain' | 'setup' | 'issues' | 'ecosystem') => void;
  onSelectDemo?: (repo: string) => void;
}

interface CoreKeyword {
  keyword: string;
  name: string;
  tagline: string;
  category: string;
  icon: React.ReactNode;
  description: string;
}

const CORE_KEYWORDS: CoreKeyword[] = [
  {
    keyword: 'gitdiagram',
    name: 'GitDiagram',
    tagline: 'System Architecture Flowchart',
    category: 'Architecture',
    icon: <Layers className="w-3.5 h-3.5 text-blue-500" />,
    description: 'Renders an interactive Mermaid.js diagram and component hierarchy directly from directory tree.',
  },
  {
    keyword: 'gitingest',
    name: 'Gitingest',
    tagline: 'Single-File Code Digest',
    category: 'Digest',
    icon: <Terminal className="w-3.5 h-3.5 text-slate-400" />,
    description: 'Packs all files into a single text digest formatted for ingestion.',
  },
  {
    keyword: 'gitreverse',
    name: 'GitReverse',
    tagline: 'Reverse-Engineered Data Models',
    category: 'Architecture',
    icon: <Code2 className="w-3.5 h-3.5 text-slate-400" />,
    description: 'Extracts data contracts, component hierarchies, and inferred database schemas automatically.',
  },
  {
    keyword: 'explaingithub',
    name: 'ExplainGitHub',
    tagline: 'Codebase Walkthrough',
    category: 'Documentation',
    icon: <BookOpen className="w-3.5 h-3.5 text-slate-400" />,
    description: 'Structured technical breakdown of algorithms and file responsibilities line by line.',
  },
  {
    keyword: 'uithub',
    name: 'Uithub',
    tagline: 'Web File Reader',
    category: 'Browser',
    icon: <Search className="w-3.5 h-3.5 text-slate-400" />,
    description: 'High-speed browser interface for exploring raw source files and directory trees.',
  },
  {
    keyword: 'github1s',
    name: 'GitHub1s',
    tagline: 'In-Browser VS Code Session',
    category: 'IDE',
    icon: <FileCode className="w-3.5 h-3.5 text-blue-500" />,
    description: 'Opens a complete VS Code editor session in WebAssembly with symbol search and code navigation.',
  },
  {
    keyword: 'deepwiki',
    name: 'DeepWiki',
    tagline: 'Technical Domain Wiki',
    category: 'Wiki',
    icon: <BookOpen className="w-3.5 h-3.5 text-slate-400" />,
    description: 'Generates structured technical documentation covering architecture boundaries and pipelines.',
  },
];

export const WelcomeHero: React.FC<WelcomeHeroProps> = ({ onQuickAction, onSelectDemo }) => {
  const [selectedKeyword, setSelectedKeyword] = useState<string>('gitdiagram');
  const [copied, setCopied] = useState<boolean>(false);
  const sampleRepo = 'tailwindlabs/tailwindcss';

  const currentTool = CORE_KEYWORDS.find((k) => k.keyword === selectedKeyword) || CORE_KEYWORDS[0];
  const transformedUrl = `https://${selectedKeyword}.com/${sampleRepo}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(transformedUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="w-full max-w-3xl mx-auto px-4 py-4 space-y-6">
      {/* Primary Engineering Header */}
      <div className="p-6 sm:p-8 rounded-xl bg-white dark:bg-[#161B22] border border-slate-200 dark:border-slate-800 text-left space-y-3">
        <div className="flex items-center gap-2">
          <span className="px-2 py-0.5 rounded text-[11px] font-mono font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
            Open-Source Engineering Tool
          </span>
          <span className="text-slate-400 text-xs font-mono">v1.2.0</span>
        </div>
        <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
          Repository Architecture & Setup Inspector
        </h2>
        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed max-w-2xl">
          Inspect public GitHub repositories to extract deterministic local environment setup commands, parse verified CI test workflows, and navigate keyword swap integrations.
        </p>

        {/* Action Buttons with Clean Rectangular Geometry */}
        <div className="pt-2 flex flex-wrap gap-2">
          <button
            onClick={() => onQuickAction('explain')}
            className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-medium border border-slate-200 dark:border-slate-700 transition-colors"
          >
            Explain Structure
          </button>
          <button
            onClick={() => onQuickAction('setup')}
            className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-medium border border-slate-200 dark:border-slate-700 transition-colors"
          >
            Setup Commands
          </button>
          <button
            onClick={() => onQuickAction('issues')}
            className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-medium border border-slate-200 dark:border-slate-700 transition-colors"
          >
            Good First Issues
          </button>
          <button
            onClick={() => onQuickAction('ecosystem')}
            className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-medium border border-slate-200 dark:border-slate-700 transition-colors"
          >
            Keyword Swap Matrix
          </button>
        </div>
      </div>

      {/* 1-Word GitHub URL Swap Matrix */}
      <div className="p-6 rounded-xl bg-white dark:bg-[#161B22] border border-slate-200 dark:border-slate-800 text-left space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-semibold bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 border border-blue-200 dark:border-blue-900/50">
                URL Swap Pattern
              </span>
              <span className="text-[11px] font-mono text-slate-400">
                https://[keyword].com/[username]/[repo name]
              </span>
            </div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Domain Keyword Swap Integrations
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Change the domain in any GitHub URL to navigate directly to these developer platforms.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleCopy}
              className="px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 flex items-center gap-1.5 transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy URL'}</span>
            </button>
            <a
              href={transformedUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-blue-600 hover:bg-blue-500 text-white flex items-center gap-1.5 transition-colors"
            >
              <span>Launch {currentTool.name}</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

        {/* Dynamic Formula Display */}
        <div className="p-3 rounded-lg bg-slate-50 dark:bg-[#0D1117] border border-slate-200 dark:border-slate-800 font-mono text-xs flex flex-wrap items-center justify-between gap-2">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-slate-400">https://</span>
            <span className="line-through text-slate-400 font-medium">github</span>
            <ArrowRight className="w-3 h-3 text-slate-400" />
            <span className="px-1.5 py-0.5 rounded bg-blue-600 text-white font-bold">
              {selectedKeyword}
            </span>
            <span className="text-slate-900 dark:text-white font-semibold">.com/{sampleRepo}</span>
          </div>
          <span className="text-[10px] text-slate-500 font-mono">Direct Deep Link</span>
        </div>

        {/* 7 Clean Tool Selector Buttons (No Emojis, No Pills) */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-1.5">
          {CORE_KEYWORDS.map((tool) => {
            const isSelected = selectedKeyword === tool.keyword;
            return (
              <button
                key={tool.keyword}
                onClick={() => setSelectedKeyword(tool.keyword)}
                className={`p-2 rounded-lg border text-left transition-colors flex flex-col justify-between ${
                  isSelected
                    ? 'bg-blue-50 dark:bg-blue-950/40 border-blue-500 text-blue-900 dark:text-blue-100'
                    : 'bg-white dark:bg-slate-900/40 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <div className="p-1 rounded bg-slate-100 dark:bg-slate-800">{tool.icon}</div>
                  {isSelected && <span className="w-1.5 h-1.5 rounded-sm bg-blue-600" />}
                </div>
                <div>
                  <div className="font-mono text-xs font-bold truncate">
                    {tool.keyword}
                  </div>
                  <div className="text-[10px] text-slate-400 truncate mt-0.5">
                    {tool.category}
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Description */}
        <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-900/40 border border-slate-200 dark:border-slate-800 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="text-slate-600 dark:text-slate-300 leading-relaxed">
            <strong className="text-slate-900 dark:text-white font-semibold">{currentTool.name}</strong>: {currentTool.description}
          </div>
          {onSelectDemo && (
            <button
              onClick={() => onSelectDemo(sampleRepo)}
              className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline shrink-0"
            >
              Analyze {sampleRepo}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
